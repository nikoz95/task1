﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TextComparator.models;
using System.Text;

namespace TextComparator.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Text texts)
        {
            string[] stringSeparators = new string[] { "\r\n" ," "};

            string[] textsTwoRow = texts.stringTwo.Split(new string[] { stringSeparators[0] }, StringSplitOptions.None);
            string[] textsOneRow = texts.stringOne.Split(new string[] { stringSeparators[0] }, StringSplitOptions.None);
           
            string[] test=new string[] { };
            string[][] jaggedArray2 = new string[][] { };

            

            Console.WriteLine(jaggedArray2);

            string[] textsOne = texts.stringOne.Split(stringSeparators, StringSplitOptions.None);
            string[] textsTwo = texts.stringTwo.Split(stringSeparators, StringSplitOptions.None);
            List<string> diff;
            
                diff = textsTwo.Except(textsOne).ToList();
            
            Console.WriteLine(diff);

            return View();
        }
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
