﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TextComparator.models
{
    public class Text
    {
        public string stringOne { get; set; }
        public string stringTwo { get; set; }
    }
}
